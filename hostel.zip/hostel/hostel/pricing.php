<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Pricing</title>
    <link rel="stylesheet" href="css\pricing.css">

    <script type="text/javascript">
      function change(){
        window.location.href ="registration.php";
      }
      function rtohome(){
        window.location.href ="index.php";
      }
    </script>
  </head>

  <body>
  <style>
 .Nav{
    background:#12343b;
    }
    </style>
    <div class="Nav" id="Nav1">
      <div class="NavbarContainer">
        <img src="images/images.png" alt="" class="NavLogo" onclick="rtohome()">
        <div class="MobileIcon">
        <i class="fa fa-bars"></i>
        </div>
        <ul class="NavMenu ">
          <li class="NavItem"><a id="linkcolor" on class="NavLinks" href="index.php#about">About</a></li>
          <li class="NavItem"><a id="linkcolor1" class="NavLinks" href="pricing.php">Blocks</a></li>
          <li class="NavItem"><a id="linkcolor2" class="NavLinks" href="index.php#contact">Contact Us</a></li>
          <li class="NavItem"><a id="linkcolor3" class="NavLinks" href="signin.php">Sign in</a></li>
        </ul>
        <div class="NavBtn">
          <button type="button" name="button" class="NavBtnLink" onclick="change()">Signup</button>
        </div>

      </div>
    </div>



    <div class="pricingcontainer">
      <div class="pricingwrapper">
        <div class="columns">
  <ul class="price">
    <li class="header">Chithravathi(Girls)</li>
    <div class="imagewrapper">
    <img style="height:150px; width:150px;" src="images/h1.jpg" alt="">
    </div>

    <li class="grey">(E2-E4)</li>
    <li>Best Internet</li>
    <li>3 Members For one Room</li>
    <li>Continues Water Supply</li>
    <li>GYM</li>
    <li class="grey"><a href="registration.php" class="button">choose</a></li>
  </ul>
</div>


<div class="columns">
<ul class="price">
<li class="header">Kundu(Girls)</li>
<div class="imagewrapper">
<img style="height:150px; width:150px;" src="images/5.png" alt="">
</div>

<li class="grey">(P1-E1)</li>
<li>Best Internet</li>
<li>8 Members For one Room</li>
<li>Continues Water Supply</li>
<li>Weekly Movie on Projector</li>
<li class="grey"><a href="registration.php" class="button">choose</a></li>
</ul>
</div>

<div class="columns">
<ul class="price">
<li class="header">Penna(Boys)</li>
<div class="imagewrapper">
<img style="height:150px; width:150px;" src="images/h3.jpg" alt="">
</div>
<li class="grey">(P1-E1)</li>
<li>Best Internet</li>
<li>8 Members For one Room</li>
<li>Continues Water Supply</li>
<li>Weekly Movie on Projector</li>

<li class="grey"><a href="registration.php" class="button">choose</a></li>
</ul>
</div>


<div class="columns">
<ul class="price">
<li class="header">Papagni(Boys)</li>
<div class="imagewrapper">
<img style="height:150px; width:150px;" src="images/9.jpg" alt="">
</div>
<li class="grey">(E2-E3)</li>
<li>Best Internet</li>
    <li>3 Members For one Room</li>
    <li>Continues Water Supply</li>
    <li>GYM</li>
<li class="grey"><a href="registration.php" class="button">choose</a></li>
</ul>
</div>


<!--
<div class="columns">
<ul class="price">
<li class="header">G block(Boys)</li>
<div class="imagewrapper">
<img style="height:150px; width:150px;" src="images/4.png" alt="">
</div>
<li class="grey">85 Thousand/ year</li>
<li>AC block</li>
<li>Common reading room</li>
<li>Indoor games</li>
<li>GYM</li>

<li class="grey"><a href="registration.php" class="button">choose</a></li>
</ul>
</div>


<div class="columns">
<ul class="price">
<li class="header">H block(Boys)</li>
<div class="imagewrapper">
<img style="height:150px; width:150px;" src="images/4.png" alt="">
</div>

<li class="grey">50 Thousand/ year</li>
<li>Non-Ac block</li>

<li>comfortable living area</li>
<li>Free wifi</li>
<li class="grey"><a href="registration.php" class="button">choose</a></li>
</ul>
</div>-->

      </div>
    </div>

  </body>
</html>
