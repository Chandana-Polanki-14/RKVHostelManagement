<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Insertion</title>
</head>
<body>

    <h1>Menu</h1>

    <!-- Replace 'your-image-path.jpg' with the actual path to your image file -->
    <img src=images/m.png" alt="Description of the image">

</body>
</html>

