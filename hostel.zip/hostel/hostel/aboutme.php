<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"/>
   <link rel="stylesheet" href="css\aboutme.css">
   <title>Contact us</title>


</head>
<body>
  <div class="heading" >
      <h1>Our Team</h1>
  </div>

    <div class="container">

        <div class="card">
            <div class="content">
                <div class="imgBx">
                    <img src="images\image3.jpeg" alt="">
                </div>
                <div class="contentBx">
                    <h4>Shama</h4>
                    <h5>Student</h5>
		    <h3>shama@gmail.com</h3>
                </div>
                
            </div>
        </div>
        <div class="card">
            <div class="content">
                <div class="imgBx">
                    <img src="images\image3.jpeg" alt="">
                </div>
                <div class="contentBx">
                    <h4>Chandana</h4>
                    <h5>Student</h5>
                    <h3>chandana@gmail.com</h3>
  		 
                </div>
                
            </div>
        </div>
        <div class="card">
            <div class="content">
                <div class="imgBx">
                    <img src="images\image3.jpeg" alt="">
                </div>
                <div class="contentBx">
                    <h4>Guru Prasad</h4>
                    <h5>Student</h5>
                    <h3>guru@gmail.com</h3>
  		 
                </div>
                
            </div>
        </div>
        <div class="card">
            <div class="content">
                <div class="imgBx">
                    <img src="images\image3.jpeg" alt="">
                </div>
                <div class="contentBx">
                    <h4>Anjali</h4>
                    <h5>Student</h5>
                    <h3>anjalirekha625@gmail.com</h3>
                </div>
                
            </div>
        </div>

    </div>
</body>
</html>
