<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="..\css\board.css">
    <script type="text/javascript">
      function studentsearch(){
 	 	window.location.href ="studentsearch.php";
	}
	function requests(){
  		window.location.href ="leaverequests.php";
	}
	function roomdetails(){
  		window.location.href ="roomdetails.php";
	}
	function complaintrequest(){
  		window.location.href ="complaint_req.php";
	}
      function feedback(){
        window.location.href ="check_feedback.php";

      }
      function back(){
        window.location.href ="../admin/adminsignin.php";
      }
      
    </script>
  </head>
  <body style="background-image:url('https://wallpaperset.com/w/full/1/5/d/522737.jpg');">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


 <style>
    .body {
 /*width: 100vw;*/
 background-image:url('https://wallpaperset.com/w/full/1/5/d/522737.jpg');
 background-color:#a28089;/*#bfd8d2;*/
 margin: 0;
 font-family: helvetica;
}

/*.wrapper {
background-image:url('https://wallpaperset.com/w/full/1/5/d/522737.jpg');
   background-size:cover;
 width: 150vw;
 margin: 0 auto;
 height: 200px;
 display: flex;
 justify-content: center;
 align-items: center;
 position: relative;
 transition: all 0.3s ease;
}*/
.card {
 width: 100%;
 max-width: 300px;
 min-width: 200px;
 height: 250px;
 background-color: #363a57;
 margin-top: 100px;
 border-radius: 10px;
 box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.24);
 border: 2px solid rgba(7, 7, 7, 0.12);
 font-size: 16px;
 transition: all 0.3s ease;
 position: relative;
 display: flex;
 justify-content: center;
 align-items: center;
 flex-direction: column;
 cursor: pointer;
 transition: all 0.3s ease;
}
.card .title {
 width: 80%;
 margin: 0;
 text-align: center;
 margin-top: 30px;
 color:white;
 font-weight: 600;
 font-size: 10px;
 text-transform: uppercase;
 letter-spacing: 4px;
}

.card .text {
 width: 80%;
 margin: 0 auto;
 font-size: 10px;
 text-align: center;
 margin-top: 20px;
 color:white;
 font-weight: 200;
 letter-spacing: 2px;
 opacity: 0;
 max-height:0;
 transition: all 0.3s ease;
}
.icon {
 margin: 0 auto;
 width: 100%;
 height: 80px;
 max-width:80px;
 background: linear-gradient(90deg, #FF7E7E 0%, #FF4848 40%, rgba(0, 0, 0, 0.38) 60%);
 border-radius: 100%;
 display: flex;
 justify-content: center;
 align-items: center;
 color: black;
 transition: all 0.8s ease;
 background-position: 0px;
 background-size: 200px;
}
.content {
 max-width: 3000px;
 display:grid;
   grid-template-columns: auto auto auto auto;
 width: 100%;
 padding: 0 4%;
 padding-top: 250px;
 margin: 0 auto;
 display: flex;
 justify-content: center;
 align-items: center; /*292929*/
}
 .back-button {
            background: linear-gradient(45deg, rgba(255, 0, 0, 0.7), rgba(0, 0, 255, 0.7));
            color: #fff;
            border: none;
            padding: 20px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
</style>

<div class="wrapper">

   <div class="content">
      <!-- card -->
      <div class="card" onclick="roomdetails()">

             <img style="height:150px; width:150px;" src="../images/c2.png" alt="">
            <p class="title">Room details</p>
            <p class="text">Check all student room details.</p>

      </div>
      <!-- end card -->

      <!-- card -->
      <div class="card" onclick="studentsearch()">
		 <img style="height:150px; width:150px;" src="../images/c12.png" alt="">
            <p class="title">Student Search</p>
            <p class="text">Search for a student .</p>

      </div>
      <!-- end card -->

      <!-- card -->
      <div class="card" onclick="requests()">

             <img style="height:150px; width:150px;" src="../images/c5.png" alt="">
            <p class="title">Leave Requests</p>
            <p class="text">Approve or reject leave requests.</p>

      </div>
       <div class="card" onclick="complaintrequest()">

            <img style="height:150px; width:150px;" src="../images/c9.png" alt="">
            <p class="title"> Complaint Requests</p>
            <p class="text">Sort or Decline requests.</p>

      </div>
      
        <div class="card"  onclick="feedback()">

            <img style="height:150px; width:150px;" src="../images/f5.png" alt="">
            <p class="title">Mess Feedback</p>
            <p class="text">Check Mess Feedback</p>

      </div>
      <!-- end card -->
      

		
   </div>

	
</div>
    <button class="back-button" onclick="back()" style="margin-top:250px;margin-left:700px; padding-left:25px;padding-right:25px;">Back</button>

		



  </body>
 		
      </div>
</html>
