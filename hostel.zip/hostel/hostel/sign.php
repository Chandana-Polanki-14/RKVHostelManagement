<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script type="text/javascript">
      function back(){
        window.location.href ="index.php";
      }
    </script>
     <style>
        body {
            
    		background-image:url('https://img.freepik.com/premium-vector/geometric-gradient-technology-background_23-2149110132.jpg?size=626&ext=jpg&ga=GA1.1.1546980028.1703203200&semt=ais');
   			background-size:cover;
            background-position: center;
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.8); /* Transparent white background */
            padding: 20px;
            border-radius: 10px;
            width: 300px;
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .txt_field {
            margin-bottom: 20px;
        }

        .login-button {
            width: 100%;
        }

        .back-button {
            width: 100%;
        }

        .signup-link {
            text-align: center;
        }
    </style>
  <?php
    $errmsg="";
  if ($_SERVER['REQUEST_METHOD']=='POST'){

       session_start();
  $username = $_POST['username'];
  $password = $_POST['password'];
  require_once('dbConnect.php');
  $sql= "SELECT * FROM users WHERE regno = '$username' AND password = '$password' ";
  $result = mysqli_query($conn,$sql);
  $check = mysqli_fetch_array($result);
  if(isset($check)){
        $_SESSION['regno'] = $username;
    header('Location: student\board.php');

  }

  else{
  $errmsg="*Username or password is wrong";
  }
  }

   ?>
   
    <title>Transparent Login Page</title>
</head>
<body>

<div class="login-container">
    <h2>Login</h2>
    <form method="post" action="sign.php">
        <div class="txt_field">
            <label for="idNumber">ID Number</label>
            <input type="text" name="username"   class="form-control" pattern="^R[0-9]{6}" required placeholder="Enter your ID Number">
        </div>
        <div class="txt_field">
            <label for="password">Password</label>
            <input type="password" name="password" class="form-control"  placeholder="Enter your password" required>
        </div>
        <button type="submit" class="btn btn-primary login-button" value="Login">Login</button><br><br>
    <input type="submit" class="btn btn-primary login-button" value="Go Back" onclick="back()" style="margin-bottom:5px;">
    <p class="signup-link">Not a member? <a href="registration.php"">Sign up</a></p>
    <span style="color:red "><?php echo "$errmsg"; ?></span>
    </form>
</div>

</body>
</html>

