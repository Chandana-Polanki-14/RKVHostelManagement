<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>complaint status</title>

<?php       session_start(); ?>
<?php

  $regno = $_SESSION['regno']; 
  require('../dbConnect.php'); 
  $sql="SELECT  *FROM raisecomplaint WHERE regno='$regno';";
  $query=mysqli_query($conn,$sql);
?>
    <style>
        /* Add custom styles here */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
        }

        .table-container {
            margin-top: 20px;
            display: flex;
            justify-content: center;
        }

        table {
            width: 80%;
            max-width: 600px;
            border-collapse: collapse;
            background-color: #000;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            color: #fff;
        }

        th {
            background-color: tomato;
        }

        tr:hover {
            background-color: #333;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2 class="mt-4">Cute Table Example</h2>
        <div class="table-container">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                <?php while($rows=mysqli_fetch_assoc($query))
				{
				?>
                    <tr>
                       <td><?php echo $rows['name']; ?></td>
						<td><?php echo $rows['regno']; ?></td>
						<td><?php echo $rows['block']; ?></td>
						<td><?php echo $rows['roomno']; ?></td>
    					<td><?php echo $rows['reason']; ?></td>
      					<td><?php echo $rows['status']; ?></td> 
                    </tr>
                    <?php
                }
          ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies (you may need to include jQuery) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>

