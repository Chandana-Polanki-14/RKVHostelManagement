<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>leave status</title>
    <script type="text/javascript">
    function back() {
      window.location.href = "board.php";
    }
    </script>

<?php       session_start(); ?>
<?php

  $regno = $_SESSION['regno']; 
  require('../dbConnect.php'); 
  $sql="SELECT  *FROM leaverequests WHERE regno='$regno';";
  $query=mysqli_query($conn,$sql);
?>
<!--
<style media="screen">
table {
    border-collapse:separate;
    border:solid black 1px;
    border-radius:6px;
    margin-left: 30%;
    margin-top: 15px;

}

td, th {
    border-left:solid black 1px;
    border-top:solid black 1px;
        padding: 10px;
}

th {
    background-color: #292929;
    border-top: none;
    color: white;
}

td:first-child, th:first-child {
     border-left: none;
}
</style>-->
<style>
    body{
    background-image:url('../images/f1.jpg');
    background-size:cover;
    }
    .table-container {
         margin-top: 20px;
            display: flex;
            justify-content: center;
        }

        table {
            width: 200%;
            max-width: 800px;
            border-collapse: collapse;
            background-color: #000;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            color: #fff;
        }

        th {
            background-color: tomato;
        }

        tr:hover {
            background-color: #333;
        }
           .back-button-container {
            text-align: center;
            margin-top: 20px;
        }
	.NavBtnLink{
  border-radius: 50px;
  background: orange;
  whitespace: nowrap;
  padding: 10px 22px;
  color: #010606;
  font-size: 16px;
  outline: none;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
  text-decoration: none;

}

	.NavBtnLink:hover{

    transition: all 0.2s ease-in-out;
    background: orange;
    color: #010606;

}
    </style>
</head>

  <body>
<?php include '../header.php';?>

<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

		 <div class="container">
        <h1 class="mt-4" align="center" style="color:balck">Leave Status</h2>
        <div class="table-container">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th> NAME</th>
			  			<th> REGNO </th>
			  			<th> BLOCK </th>
			  			<th> ROOMNO </th>
                          <th> FROMDATE </th>
                          <th> TODATE </th>
                          <th> REASON </th>
                          <th> STATUS </th>
                    </tr>
                </thead>
                <tbody>
	
<?php while($rows=mysqli_fetch_assoc($query))
		{
		?>
		<tr> <td><?php echo $rows['name']; ?></td>
		<td><?php echo $rows['regno']; ?></td>
		<td><?php echo $rows['block']; ?></td>
		<td><?php echo $rows['roomno']; ?></td>
    	<td><?php echo $rows['fromdate']; ?></td>
      	<td><?php echo $rows['todate']; ?></td>
        <td><?php echo $rows['reason']; ?></td>
      	<td><?php echo $rows['status']; ?></td>
		</tr>
	<?php
               }
          ?>

</tbody>
         </table>
        </div>
    </div>


</table>
<div class="back-button-container">
          <button type="button" name="button" class="NavBtnLink" onclick="back()" style="margin:20px 700px" >BACK</button>  
        </div>
    </div>
</body>
</html>
