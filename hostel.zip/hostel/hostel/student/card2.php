<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Two Cards Page</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      padding: 20px;
    }

    .navbar {
      margin-bottom: 20px;
    }

    .custom-card {
      margin-top: 10px;
    }
  </style>
</head>
<body>
 <?php       session_start(); ?>

      <?php

      if($_SERVER["REQUEST_METHOD"]=="POST"){
    require_once('../dbConnect.php');
        $regno =  $_SESSION['regno'];
        if(isset($_POST["papagni"])){
          $blockname="Papagni";
          $rowSQL = mysqli_query($conn, "SELECT MAX( roomno ) AS max FROM `users` WHERE block='$blockname' AND gender='male';" );
          $row = mysqli_fetch_array( $rowSQL );
          $largestNumber = $row['max'];
          if($largestNumber==0){
            $largestNumber=1;
          }
          $result=mysqli_query($conn,"SELECT count(*) as total from users where block='$blockname' AND gender='male';");
        $data=mysqli_fetch_assoc($result);
        $count= $data['total'];
        if($count % 3 == 0){
          $roomno=$largestNumber + 1;
        }
        else{
            $roomno=$largestNumber;
        }
        }
    if(isset($_POST["penna"])){
      $blockname="Penna";
      $rowSQL = mysqli_query($conn, "SELECT MAX( roomno ) AS max FROM `users` WHERE block='$blockname' AND gender='male';" );
      $row = mysqli_fetch_array( $rowSQL );
      $largestNumber = $row['max'];
      if($largestNumber==0){
        $largestNumber=1;
      }
      $result=mysqli_query($conn,"SELECT count(*) as total from users where block='$blockname' AND gender='male';");
    $data=mysqli_fetch_assoc($result);
    $count= $data['total'];
    if($count % 8 == 0){
      $roomno=$largestNumber+1;
    }
    else{
        $roomno=$largestNumber;
    }
    }
    
    $sql="UPDATE `users` SET `block`='$blockname' where regno='$regno'";
    $query=mysqli_query($conn,$sql);
    $sql="UPDATE `users` SET `roomno`='$roomno' where regno='$regno'";
    $query1=mysqli_query($conn,$sql);
    if($query && $query1){
      echo 'Entry successful';
      header('Location: board.php');
    }
    else{
      echo "error occoured";
    }
    }
       ?>
<?php include '../header.php';?>

  <form class="" action="card2.php" method="post">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-4 custom-card" style="margin-top:50px;">
        <div class="card">
          <img src="../images/10.jpg" class="card-img-top" alt="Image 1" height="250px">
          <div class="card-body">
            <h5 class="card-title">Papagni</h5>
            <p class="card-text">Hostel for E2-E4.</p>
            <button type="submit" name="papagni" id="papagni" class="btn btn-primary">Submit</button>
          </div>
        </div>
      </div>

      <div class="col-md-4 custom-card" style="margin-top:50px;">
        <div class="card">
          <img src="../images/9.jpg" class="card-img-top" alt="Image 2" height="250px">
          <div class="card-body">
            <h5 class="card-title">Penna</h5>
            <p class="card-text">Hostel for P1-E1</p>
            <button type="submit" name="penna" id="penna" class="btn btn-primary">Submit</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  </form>

  <!-- Bootstrap JS and dependencies (jQuery, Popper.js) -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>

