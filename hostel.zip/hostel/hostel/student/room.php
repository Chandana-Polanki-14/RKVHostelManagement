<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Information</title>
    <script type="text/javascript">
    function back() {
      window.location.href = "board.php";
    }
    </script>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image:url('../images/r5.jpg');
    		background-size:cover;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            flex-direction: column; /* Added to arrange items in a column */
        }

        .gradient-card {
            width: 300px;
            height: 400px; /* Adjusted height to accommodate more content */
            border-radius: 10px;
            background: linear-gradient(45deg, rgba(255, 0, 0, 0.7), rgba(0, 0, 255, 0.7));
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            color: #fff;
            text-align: center;
            margin-bottom: 20px; /* Added margin to separate card and button */
        }

        .back-button {
            background: linear-gradient(45deg, rgba(255, 0, 0, 0.7), rgba(0, 0, 255, 0.7));
            color: #fff;
            border: none;
            padding: 20px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php session_start(); ?>
    <?php
        $regno = $_SESSION['regno'];
        require_once('../dbConnect.php');
        $sql = "SELECT name, email, phoneno, block, roomno FROM users WHERE regno='$regno';";
        $query = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($query);
        $name = $row['name'];
        $email = $row['email'];
        $phoneno = $row['phoneno'];
        $block = $row['block'];
        $roomno = $row['roomno'];
    ?>
    <div class="gradient-card">
        <h4><b><?php echo "Name: $name"; ?></b></h4>
        <br>
        <p><b><?php echo "Reg_no: $regno"; ?></b></p>
        <br>
        <p><b><?php echo "Email: $email"; ?></b></p>
        <br>
        <p><b><?php echo "Phoneno: $phoneno"; ?></b></p>
        <br>
        <p><b><?php echo "Block: $block"; ?></b></p>
        <br>
        <p><b><?php echo "Roomno: $roomno"; ?></b></p>
    </div>

    <button class="back-button" onclick="back()">Back</button>
</body>
</html>

