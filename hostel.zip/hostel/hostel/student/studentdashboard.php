<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="..\css\studentdashboard.css">
    <script type="text/javascript">
      function leavestatus(){
        window.location.href ="leavestatus.php";
      }
      function applyleave(){
        window.location.href ="applyleave.php";
      }
      function roomdetails(){
        window.location.href ="room.php";

      }
      function searchroommates(){
        window.location.href ="roommatesearch.php";

      }
        function raisecomplaint(){
        window.location.href ="raisecomplaint.php";

      }
      function complaintstatus(){
        window.location.href ="complaintstatus.php";

      }
      
    </script>
  </head>
  <body style="background-image:url('/opt/lampp/htdocs/hostel/images/b1.jpeg')"
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


 <style>
    body {
 width: 100vw;
 background-image:url('/opt/lampp/htdocs/hostel/images/b1.jpeg');
 background-repeat:no-repeat;
 /*background-color:#a28089;/*#bfd8d2;*/
 margin: 0;
 font-family: helvetica;
}

.wrapper {
background-image:url('/opt/lampp/htdocs/hostel/images/b1.jpeg');
 background-repeat:no-repeat;
 width: 150vw;
 margin: 0 auto;
 height: 200px;
 background-color: black;  /*#a28089; /*#e1b382;*/
 display: flex;
 justify-content: center;
 align-items: center;
 position: relative;
 transition: all 0.3s ease;
}
.card {
 width: 100%;
 max-width: 300px;
 min-width: 200px;
 height: 250px;
 background-color: #363a57;
 margin-top: 100px;
 border-radius: 10px;
 box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.24);
 border: 2px solid rgba(7, 7, 7, 0.12);
 font-size: 16px;
 transition: all 0.3s ease;
 position: relative;
 display: flex;
 justify-content: center;
 align-items: center;
 flex-direction: column;
 cursor: pointer;
 transition: all 0.3s ease;
}
.card .title {
 width: 80%;
 margin: 0;
 text-align: center;
 margin-top: 30px;
 color:white;
 font-weight: 600;
 font-size: 10px;
 text-transform: uppercase;
 letter-spacing: 4px;
}

.card .text {
 width: 80%;
 margin: 0 auto;
 font-size: 10px;
 text-align: center;
 margin-top: 20px;
 color:white;
 font-weight: 200;
 letter-spacing: 2px;
 opacity: 0;
 max-height:0;
 transition: all 0.3s ease;
}
.icon {
 margin: 0 auto;
 width: 100%;
 height: 80px;
 max-width:80px;
 background: linear-gradient(90deg, #FF7E7E 0%, #FF4848 40%, rgba(0, 0, 0, 0.38) 60%);
 border-radius: 100%;
 display: flex;
 justify-content: center;
 align-items: center;
 color: black;
 transition: all 0.8s ease;
 background-position: 0px;
 background-size: 200px;
}
.content {
 max-width: 3000px;
 display:grid;
   grid-template-columns: auto auto auto auto;
 width: 100%;
 padding: 0 4%;
 padding-top: 250px;
 margin: 0 auto;
 display: flex;
 justify-content: center;
 align-items: center; /*292929*/
}

</style>

<div class="wrapper">

   <div class="content">
      <!-- card -->
      <div class="card" onclick="searchroommates()">
		<img style="height:150px; width:150px;" src="../images/c11.jpeg" alt="">
           <!-- <div class="icon"><i class="material-icons md-36">search</i></div>-->
            <p class="title">Find Roommates</p>
            <p class="text">Know your roommates.</p>

      </div>
      <!-- end card -->
      <!-- card -->
      <div class="card" onclick="roomdetails()">

            <img style="height:150px; width:150px;" src="../images/c2.png" alt="">
            <p class="title">My Room Details</p>
            <p class="text">Check your room details.</p>

      </div>
      <!-- end card -->


      <!-- card -->
      <div class="card"  onclick="applyleave()">

            <img style="height:150px; width:150px;" src="../images/c5.png" alt="">
            <p class="title">Apply Leave</p>
            <p class="text">Apply for leave.</p>

      </div>
      <!-- end card -->
      <!-- card -->
      <div class="card"  onclick="leavestatus()">

             <img style="height:150px; width:150px;" src="../images/c6.png" alt="">
            <p class="title">Leave Status</p>
            <p class="text">Check leave status.</p>

      </div>
       <div class="card"  onclick="raisecomplaint()">

             <img style="height:150px; width:150px;" src="../images/c7.png" alt="">
            <p class="title">Raise Complaint</p>
            <p class="text">Raise Complaint if you have any</p>

      </div>
       <div class="card"  onclick="complaintstatus()">

            <img style="height:150px; width:150px;" src="../images/c9.png" alt="">
            <p class="title">Complaint Status</p>
            <p class="text">Check Complaint Status</p>

      </div>
      
        <div class="card"  onclick="complaintstatus()">

            <img style="height:150px; width:150px;" src="../images/c9.png" alt="">
            <p class="title">Feedback</p>
            <p class="text">Give Feedback</p>

      </div>
      <!-- end card -->
      
     
		
   </div>
	
</div>

		


 
  </body>
 		
      </div>
</html>
