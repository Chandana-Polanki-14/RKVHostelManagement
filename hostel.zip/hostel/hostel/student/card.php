<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBn+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<link rel="stylesheet" href="style7.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="bootstrap/css/bootsrap.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
 <title>website</title>
</head>
<body>
 <?php       session_start(); ?>

      <?php

      if($_SERVER["REQUEST_METHOD"]=="POST"){
    require_once('../dbConnect.php');
        $regno =  $_SESSION['regno'];
        if(isset($_POST["chithravathi"])){
          $blockname="Chithravathi";
          $rowSQL = mysqli_query($conn, "SELECT MAX( roomno ) AS max FROM `users` WHERE block='$blockname' AND gender='female';" );
          $row = mysqli_fetch_array( $rowSQL );
          $largestNumber = $row['max'];
          if($largestNumber==0){
            $largestNumber=1;
          }
          $result=mysqli_query($conn,"SELECT count(*) as total from users where block='$blockname' AND gender='female';");
        $data=mysqli_fetch_assoc($result);
        $count= $data['total'];
        if($count % 3 == 0){
          $roomno=$largestNumber + 1;
        }
        else{
            $roomno=$largestNumber;
        }
        }
    if(isset($_POST["kundu"])){
      $blockname="Kundu";
      $rowSQL = mysqli_query($conn, "SELECT MAX( roomno ) AS max FROM `users` WHERE block='$blockname' AND gender='female';" );
      $row = mysqli_fetch_array( $rowSQL );
      $largestNumber = $row['max'];
      if($largestNumber==0){
        $largestNumber=1;
      }
      $result=mysqli_query($conn,"SELECT count(*) as total from users where block='$blockname' AND gender='female';");
    $data=mysqli_fetch_assoc($result);
    $count= $data['total'];
    if($count % 3 == 0){
      $roomno=$largestNumber+1;
    }
    else{
        $roomno=$largestNumber;
    }
    }
    $sql="UPDATE `users` SET `block`='$blockname' where regno='$regno'";
    $query=mysqli_query($conn,$sql);
    $sql="UPDATE `users` SET `roomno`='$roomno' where regno='$regno'";
    $query1=mysqli_query($conn,$sql);
    if($query && $query1){
      echo 'Entry successful';
      header('Location: studentdashboard.php');
    }
    else{
      echo "error occoured";
    }
    }
    ?>

<form class="" action="card.php" method="post">
<div>
    <div class="bg-container"> 
        <div class="d-flex flex-row">
        <div class="card">
            <img src="images/h1.jpg" class="image"/>
            <h1 class="heading"><i>Chithravathi</i></h1>
            <input type="select" name="chithravathi" id="chithravathi" class="card__by" value="submit">
            <div>
               
            </div>
        </div>
        <div class="card">
            <img src="images/h2.png" class="image"/>
            <h1 class="heading"><i> Kundu</i></h1>
            <input type="select" name="chithravathi" id="chithravathi" class="card__by" value="submit">
            <div>
                
            </div>
        </div>
        <!--
        <div class="card">
            <img src="dis.jpg" class="image"/>
            <h1 class="heading"><i>Disease Helper</i></h1>
            <div>
                <a href="disease.html"><button class="btn btn-primary order">Search Disease</button></a>
            </div>
        </div>
        </div>-->
        
    </div>
    <a href="home1.html"><button class="btn btn-primary button">Back</button></a>
</div>
</body>
</html>
