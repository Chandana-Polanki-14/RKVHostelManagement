<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title></title>
  <link rel="stylesheet" href="..\css\mhreg.css">
  <style>
  .card__img {
    /* Add the background image URL and other necessary properties */
    background-image: url('/opt/lampp/htdocs/hostel/images/h1.jpg');
    background-size: cover; /* Adjust this based on your preference */
    /* Add other styling properties as needed */
    width: 100%;
    height: 200px; /* Adjust the height as needed */
  }
</style>

  </head>
  <body>
    <?php       session_start(); ?>

      <?php

      if($_SERVER["REQUEST_METHOD"]=="POST"){
    require_once('../dbConnect.php');
        $regno =  $_SESSION['regno'];
        if(isset($_POST["chithravathi"])){
          $blockname="Chithravathi";
          $rowSQL = mysqli_query($conn, "SELECT MAX( roomno ) AS max FROM `users` WHERE block='$blockname' AND gender='female';" );
          $row = mysqli_fetch_array( $rowSQL );
          $largestNumber = $row['max'];
          if($largestNumber==0){
            $largestNumber=1;
          }
          $result=mysqli_query($conn,"SELECT count(*) as total from users where block='$blockname' AND gender='female';");
        $data=mysqli_fetch_assoc($result);
        $count= $data['total'];
        if($count % 3 == 0){
          $roomno=$largestNumber + 1;
        }
        else{
            $roomno=$largestNumber;
        }
        }
    if(isset($_POST["kundu"])){
      $blockname="Kundu";
      $rowSQL = mysqli_query($conn, "SELECT MAX( roomno ) AS max FROM `users` WHERE block='$blockname' AND gender='female';" );
      $row = mysqli_fetch_array( $rowSQL );
      $largestNumber = $row['max'];
      if($largestNumber==0){
        $largestNumber=1;
      }
      $result=mysqli_query($conn,"SELECT count(*) as total from users where block='$blockname' AND gender='female';");
    $data=mysqli_fetch_assoc($result);
    $count= $data['total'];
    if($count % 8 == 0){
      $roomno=$largestNumber+1;
    }
    else{
        $roomno=$largestNumber;
    }
    }
    
   

    $sql="UPDATE `users` SET `block`='$blockname' where regno='$regno'";
    $query=mysqli_query($conn,$sql);
    $sql="UPDATE `users` SET `roomno`='$roomno' where regno='$regno'";
    $query1=mysqli_query($conn,$sql);
    if($query && $query1){
      echo 'Entry successful';
      header('Location: studentdashboard.php');
    }
    else{
      echo "error occoured";
    }
    }
       ?>
<?php include '../header.php';?>


<form class="" action="lhregistration.php" method="post">
    <section class="cards">
<article class="card card--1">
  <div class="card__img"></div>
 
  <a href="#" class="card_link">
     <div class="card__img--hover"></div>
   </a>
  <div class="card__info">
    <span class="card__category"> LH Hostel</span>
    <h3 class="card__title">Chithravathi</h3>
    <!-- <span class="card__by"> <a href="#" class="card__author" title="author">select</a></span> -->
    <input type="submit" name="chithravathi" id="chithravathi" class="card__by" value="submit">
  </div>
</article>


<article class="card card--2">

  <div class="card__img"></div>
  <a href="#" class="card_link">
     <div class="card__img--hover"></div>
   </a>
  <div class="card__info">
    <span class="card__category"> LH Hostel</span>
    <h3 class="card__title">Kundu</h3>
    <input type="submit" name="kundu" id="kundu" class="card__by" value="select">
  </div>
</article>


  </section>
</form>

  </body>
</html>
