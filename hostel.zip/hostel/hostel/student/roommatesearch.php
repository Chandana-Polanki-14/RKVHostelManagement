<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>

<?php       session_start(); ?>
<?php

  $regno = $_SESSION['regno'];
  require_once('../dbConnect.php');
  $sql="SELECT gender,block,roomno FROM users WHERE regno='$regno';";
    // $sql="SELECT regno,name,email,phoneno,block,roomno FROM users WHERE ";
  $query1=mysqli_query($conn,$sql);
  $row = mysqli_fetch_assoc($query1);
  $gender=$row['gender'];
  $block=$row['block'];
  $roomno=$row['roomno'];
  $sql="SELECT regno,name,email,phoneno,block,roomno FROM users WHERE gender='$gender' AND block='$block' AND roomno='$roomno'";
  $query=mysqli_query($conn,$sql);


 ?>

<style>
    body{
    background-image:url('../images/f1.jpg');
    background-size:cover;
    }
    .table-container {
         margin-top: 20px;
            display: flex;
            justify-content: center;
        }

        table {
            width: 200%;
            max-width: 800px;
            border-collapse: collapse;
            background-color: #000;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            color: #fff;
        }

        th {
            background-color: tomato;
        }

        tr:hover {
            background-color: #333;
        }
           .back-button-container {
            text-align: center;
            margin-top: 20px;
        }
	.NavBtnLink{
  border-radius: 50px;
  background: orange;
  whitespace: nowrap;
  padding: 10px 22px;
  color: #010606;
  font-size: 16px;
  outline: none;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
  text-decoration: none;

}

	.NavBtnLink:hover{

    transition: all 0.2s ease-in-out;
    background: orange;
    color: #010606;

}
    </style>
  </head>
  <body>
<?php include '../header.php';?>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<div class="container">
        <h1 class="mt-4" align="center" style="color:balck">Find Roomates</h2>
        <div class="table-container">
            <table class="table table-bordered">
                <thead>
                 <tr>
			  		<th> RegNo</th>
			  		<th> Name </th>
			  		<th> Phone no </th>
			  		<th> Email</th>
        			<th> Block </th>
        			<th> Room no </th>
                 </tr>
                </thead>
                <tbody>
		

		<?php while($rows=mysqli_fetch_assoc($query))
		{
		?>
		<tr> <td><?php echo $rows['regno']; ?></td>
		<td><?php echo $rows['name']; ?></td>
		<td><?php echo $rows['phoneno']; ?></td>
		<td><?php echo $rows['email']; ?></td>
    	<td><?php echo $rows['block']; ?></td>
      	<td><?php echo $rows['roomno']; ?></td>
		</tr>
	<?php
               }
          ?>
	
		</tbody>
         </table>
        </div>
    </div>

	</table>

  </body>
</html>
