<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Feedback Form</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
  <script type="text/javascript">
    function goBack() {
      window.location.href = "board.php";
    }
    </script>
  <style>
 
    body {
      padding: 20px;
      background-image:url('https://darshanhostels.com/wp-content/uploads/2019/05/IMG_9109.jpg');
       background-size:cover;
    }
    .card-header{
background-color: #cf9fff;
}
.card-body{
background-color: #ffc1cc;
}
.form-control
{
background-color: #e6e6fa;
  </style>
  
   <?php session_start(); ?>
  <?php
    $regno = $_SESSION['regno'];
    require_once('../dbConnect.php');
    $sql = "SELECT name FROM users WHERE regno='$regno';";
    $query1 = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($query1);
    $name = $row['name'];
    $errmsg = "";
    $sucmsg = "";
  ?>
</head>
<body>
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card">
          <div class="card-header">
            <h2>Feedback Form</h2>
          </div>
          <div class="card-body">
            <form action="f1.php" method="post">
              <div class="form-group row">
                <label for="name" class="col-sm-3 col-form-label">Name:</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" value="<?php echo "$name"; ?>" required pattern="[a-z A-Z]*">
                </div>
              </div>

              <div class="form-group row">
                <label for="id" class="col-sm-3 col-form-label">ID:</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" id="regno" name="regno" placeholder="Enter your ID" value="<?php echo "$regno"; ?>" pattern="^R[0-9]{6}" required>
                </div>
              </div>

              <div class="form-group">
                <label for="feedback">Feedback:</label>
                <textarea class="form-control" id="feedback" name="feedback" rows="4" placeholder="Enter your feedback"></textarea>
              </div>

              <button type="button" class="btn btn-secondary" onclick="goBack()">Back</button>
              <button type="submit" class="btn btn-primary" name="submit">Submit</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>


  <!-- Bootstrap JS and dependencies (jQuery, Popper.js) -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
if (isset($_POST['feedback'])) {
$feedback = $_POST['feedback'];
$sql = "SELECT * FROM feed WHERE regno='$regno'";
if ($result=mysqli_query($conn,$sql)) {
    $count=mysqli_num_rows($result);

}
  if($count>=1){
  $errmsg="*You already had a one complain";
  }
  else{

   require_once('../dbConnect.php');
 $sql="INSERT INTO `feed` (`name`,`regno`,`feedback`)VALUES ('$name','$regno','$feedback')";
 $query=mysqli_query($conn,$sql);
 if($query){
   $sucmsg= '*Entry successful';
 }
 else{
   $errmsg= "*Error occoured";
 }
}
}
 }
 




?>

