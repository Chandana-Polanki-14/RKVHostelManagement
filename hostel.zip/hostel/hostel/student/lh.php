<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="..\css\mhreg.css">
    <title>Card Example</title>
    <style>
      * {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); /* this adds the "card" effect */
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
}

/* Responsive columns - one column layout (vertical) on small screens */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}
        .card img {
            max-width: 100%;
            border-radius: 8px;
        }
        .row {margin: 0 -5px;}
        .column {
  float: left;
  width: 25%;
  padding: 0 10px;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}
    </style>
</head>

<body>
 <?php       session_start(); ?>

      <?php

      if($_SERVER["REQUEST_METHOD"]=="POST"){
    require_once('../dbConnect.php');
        $regno =  $_SESSION['regno'];
        if(isset($_POST["chithravathi"])){
          $blockname="Chithravathi";
          $rowSQL = mysqli_query($conn, "SELECT MAX( roomno ) AS max FROM `users` WHERE block='$blockname' AND gender='female';" );
          $row = mysqli_fetch_array( $rowSQL );
          $largestNumber = $row['max'];
          if($largestNumber==0){
            $largestNumber=1;
          }
          $result=mysqli_query($conn,"SELECT count(*) as total from users where block='$blockname' AND gender='female';");
        $data=mysqli_fetch_assoc($result);
        $count= $data['total'];
        if($count % 3 == 0){
          $roomno=$largestNumber + 1;
        }
        else{
            $roomno=$largestNumber;
        }
        }
    if(isset($_POST["kundu"])){
      $blockname="Kundu";
      $rowSQL = mysqli_query($conn, "SELECT MAX( roomno ) AS max FROM `users` WHERE block='$blockname' AND gender='female';" );
      $row = mysqli_fetch_array( $rowSQL );
      $largestNumber = $row['max'];
      if($largestNumber==0){
        $largestNumber=1;
      }
      $result=mysqli_query($conn,"SELECT count(*) as total from users where block='$blockname' AND gender='female';");
    $data=mysqli_fetch_assoc($result);
    $count= $data['total'];
    if($count % 3 == 0){
      $roomno=$largestNumber+1;
    }
    else{
        $roomno=$largestNumber;
    }
    }
    $sql="UPDATE `users` SET `block`='$blockname' where regno='$regno'";
    $query=mysqli_query($conn,$sql);
    $sql="UPDATE `users` SET `roomno`='$roomno' where regno='$regno'";
    $query1=mysqli_query($conn,$sql);
    if($query && $query1){
      echo 'Entry successful';
      header('Location: studentdashboard.php');
    }
    else{
      echo "error occoured";
    }
    }
    ?>
<?php include '../header.php';?>


<form class="" action="lh.php" method="post">

<div class="row">
  <div class="column">
    <div class="card" style="margin-top:150px";>
    <img src="/opt/lampp/htdocs/hostel/images/h1.jpg" >
        <h3>Cute Cat</h3>
       
        <input type="select" name="chithravathi" id="chithravathi" class="card__by" value="submit">
    </div>
  </div>
  <div class="column">
    <div class="card" style="margin-top:150px";>
    <img src="images/h2.jpg" alt="Cat Image">
        <h3>Cute Cat</h3>
        <p>This is a cute cat. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <input type="select" name="chithravathi" id="chithravathi" class="card__by" value="submit">
    </div>
  </div>

</body>
</html>


