<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
     body {
            
    		background-image:url('https://img.freepik.com/premium-vector/geometric-gradient-technology-background_23-2149110132.jpg?size=626&ext=jpg&ga=GA1.1.1546980028.1703203200&semt=ais');
   			background-size:cover;
            background-position: center;
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.8); /* Transparent white background */
            padding: 20px;
            border-radius: 10px;
            width: 300px;
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .txt_field {
            margin-bottom: 20px;
        }

        .login-button {
            width: 100%;
        }

        .back-button {
            width: 100%;
        }

        .signup-link {
            text-align: center;
        }
    </style>
    <?php
$errmsg="";
    if ($_SERVER['REQUEST_METHOD']=='POST'){
         session_start();
    $employeeid = $_POST['securityid'];
    $password = $_POST['password'];
    require_once('../dbConnect.php');
    $sql= "SELECT * FROM security WHERE securityid = '$securityid' AND password = '$password' ";
    $result = mysqli_query($conn,$sql);
    $check = mysqli_fetch_array($result);
    if(isset($check)){
          $_SESSION['securityid'] = $securityid;
      header('Location: security.php');

    }

    else{
    $errmsg="*Username or password is wrong";
    }
    }


     ?>
  </head>
  <body>
  <!--
    <div class="center">
      <h1>Security Login</h1>
      <form action="security.php" method="post">
        <div class="txt_field">
          <input id="securityid" name="securityid" type="text" pattern="[0-9]{5}" required>
          <span></span>
          <label>Security ID</label>
        </div>
        <div class="txt_field">
          <input id="password" name="password" type="password" required>
          <span></span>
          <label>Password</label>
        </div>
        <div class="pass">Forgot Password?</div>
        <input type="submit" name="submit" id="submit" value="submit">
        <div class="signup_link">
          Forgot? <a href="#">Contact</a>
        </div>
      </form>
        <span style="color:red;margin-left: 15px;"><?php echo "$errmsg"; ?></span>
    </div>-->
    <div class="login-container">
    <h2>Login</h2>
    <form method="post" action="security.php">
        <div class="txt_field">
            <label for="idNumber">Security ID</label>
            <input type="text" name="securityid"  id="securityid" class="form-control" pattern="[0-9]{5}" required placeholder="Enter your ID Number">
        </div>
        <div class="txt_field">
            <label for="password">Password</label>
            <input type="password" name="password" class="form-control"  placeholder="Enter your password" required>
        </div>
        <button type="submit" class="btn btn-primary login-button" value="Login">Login</button><br><br>
    <input type="submit" class="btn btn-primary login-button" value="Go Back" onclick="back()" style="margin-bottom:5px;">
    <span style="color:red "><?php echo "$errmsg"; ?></span>
    </form>
</div>

  </body>
</html>
