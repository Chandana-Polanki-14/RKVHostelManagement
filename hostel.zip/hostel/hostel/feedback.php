<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script type="text/javascript">
       function back(){
         window.location.href ="index.php";
       }
 /*    function register(){
        window.alert("ppp");
       }     */
     </script>
     <?php
        $errmsg="";
         $name="";
         $regno="";
         $feedback="";
         

     if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST["submit"])){
     $conn= mysqli_connect('localhost','root','','hms') or die("Connection failed:" .mysqli_connect_error());
     if(isset($_POST['name']) && isset($_POST['regno'])&&isset($_POST['feedback'])){

     $name=$_POST['name'];
     $regno=$_POST['regno'];
     $feed=$_POST['feedback'];
     


 
  $sql="INSERT INTO `feedback` (`name`,`regno`,`feedback`)VALUES ('$name','$regno','$feed')";
   $query=mysqli_query($conn,$sql);
   if($query){
   $errmsg= '*Entry successful';
  /* $_SESSION['regno'] = $regno;*/
   
   }
   else{
       $errmsg="*All fields are required";

       }
     

}
}

      ?>
   </head>
  <link rel="stylesheet" href="css\resgistration.css">
<body>
  <?php       session_start(); ?>


  <div class="container">
    <div class="title">Give Feedback</div>
    <div class="content">
      <form action="m1.html"   method="post">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Full Name</span>
            <input name="name" type="text" placeholder="Enter your name" value="<?php echo "$name"; ?>" required pattern="[a-z A-Z]*">
          </div>
          <div class="input-box">
            <span class="details">Reg No</span>
            <input type="text" placeholder="Enter your regno" name="regno" value="<?php echo "$regno"; ?>" pattern="[0-9]{4}" required>
          </div>
          <div class="input-box">
            <span class="details">FeedBack</span>
            <input type="text" placeholder="Enter your feedback" name="feedback" value="<?php echo "$feedback"; ?>" required>
          </div>
     
        <div class="button">
          <input type="submit" value="Go Back" onclick="back()">
          <input type="submit" value="Submit" onclick="register()" name="submit" style="margin-left:85px;">
        </div>
        <span style="color:red"><?php echo $errmsg; ?></span>
      </form>
    </div>
  </div>
  </div>

</body>
</html>

